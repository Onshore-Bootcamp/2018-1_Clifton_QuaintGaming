EYE OF THE BEHOLDER -- FULL GAME
Downloaded from Cascade Abandonware
http://home.c2i.net/olant/