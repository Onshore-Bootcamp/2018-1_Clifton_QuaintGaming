Gobliiins
version 1.000  9/11/92  DOS
Requires: 286 or better, 570k conventional memory, VGA, Mouse.
Supports:Thunderboard, Adlib, Sound Blaster, MediaVision ProAudio,
PC speaker, or no sound.

Installation:
-Unzip the download to a directory of your choice.
-Run LOADER.EXE to configure sound. If you want to reconfigure sound later,
simply run LOADER.EXE again.

Playing the game:
Run GO.BAT to start the game.
As you progress through the levels you'll be given access codes. Be sure to
write these down. Click the skull on the bottom right on the screen to enter
an access code or Quit the game.